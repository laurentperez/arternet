#!/usr/bin/perl
#
# pfxp (perl fxp)
# a spreadbot/prebot utility - beholder/BOR
# 
# see README
# 
# quick commands :
# help
# fxp <what> <from> <to> <to> <to> <to> <..>
# pre <what> <where>
# pre <what> ALL
# status
# raw <ftp command> <where>
# raw <ftp command> ALL
# quit
# sleep
# wakeup

use strict;
use Term::ANSIColor qw(:constants);
use Config::Simple;
# http://search.cpan.org/CPAN/authors/id/S/SH/SHERZODR/Config-Simple-3.10.tar.gz
use Net::FTP;
use POE;
use POE qw(Wheel::Run Filter::Reference Wheel::ReadWrite Driver::SysRW Filter::Stream Component::IRC::Plugin::Blowfish);
use POE::Component::IRC;
# use Crypt::CBC;
# use Crypt::Blowfish;
# TODO mcps
# use MIME::Base64;
# use Compress::Zlib;

$|=1;
$Term::ANSIColor::AUTORESET = 1;  

my %idle; # connected sites
my %are_used; # sites being currently used
my %default_dir; # predirs paths
my %idlecmd; # idle command
my %precmd; # pre command+syntax
my %failcount; # failures per site
my %master_warned; # irc master signals
my %spread; # chains
my %bncs; # site bouncers
my %all_bnc_down; # filled when all bnc are down
my %turtles; # sites with high latency (korea,africa)
my %logincmd; # command to send after login
my %bncconn;
my @failures;
my @connected;
my @are_in_use;

# config
my $cfgapp = new Config::Simple("bot.ini");
my $fxpon = $cfgapp->param("bot.fxpon"); 
my $debugftp = $cfgapp->param("bot.debug_ftp");                                                                                  
my $ircdebug = $cfgapp->param("bot.debug_irc");                                                                                  
my $num;
my $show_locks = 0;
my $v = "0.2";
my $timeout = $cfgapp->param("bot.timeout");                                                                                  
my $autoconnect = $cfgapp->param("bot.autoconnect");                                                                                  
my $stunnel_host = $cfgapp->param("bot.stunnel_host");
my $stunnel_port = $cfgapp->param("bot.stunnel_port");
my $dump = $cfgapp->param("bot.dump");
my $logfile = $cfgapp->param("bot.logfile");
my $cfgsite = new Config::Simple(filename => 'sites.ini', autosave => 1);                                                     
$cfgsite->write('sites.bak'); # little security                                                                               
my @SITES = $cfgsite->block();      
my $masterchannel = $cfgapp->param("bot.masterchannel");
my $masterchankey = $cfgapp->param("bot.masterchankey");
my $masterbfkey = $cfgapp->param("bot.masterbfkey");
my $botnick = $cfgapp->param("bot.nick");
my $botaltnick = $cfgapp->param("bot.altnick");
my $flood = $cfgapp->param("bot.flood") || "0";
my @masters = split(',',$cfgapp->param("bot.masters"));
my @servers = split(',',$cfgapp->param("bot.servers"));
my $ssl_ircd = $cfgapp->param("bot.ssl_ircd");
my $irc_connected;
my $supermaster = $cfgapp->param("bot.supermaster");
my $trace = 0; #poe

# poe handlers
my $_irc = POE::Component::IRC->spawn(
 nick     => $botnick,
    ircname  => 'doe',
    username => 'john',
    debug    => $ircdebug,
    plugin_debug => 0,
	) or die "failed: $!\n";
sub irc { $_irc }

POE::Session->create(
	 inline_states =>{
_start => \&bot_start,                                                                                                          
irc_001    => \&on_connect,  
irc_433 =>   \&on_nick_taken,                                                                                                  
irc_public => \&on_public,                                                                                                      
irc_msg     => \&on_msg,     
irc_invite => \&on_invite,                                                                                                   
irc_disconnected    => \&on_disconnect,                                                                                         
irc_error   => \&on_ircerror,                                                                                                   
irc_socketerr => \&on_ircsocketerr,
autoping	=> \&irc_ping,
st_out      => \&st_out,                                                                                                        
st_cl       => \&st_cl,                                                                                                         
st_err      => \&st_err,                                                                                                        
keep_idle   => \&keep_idle,                                                                                                     
log_and_idle    => \&log_and_idle,                                                                                              
term_input	=> \&term_input,
term_error	=> \&term_error,
ping_ircd	=> \&ping_ircd,
site_connect	=> \&site_connect,},
heap => { irc => $_irc },
options => { trace => $trace, default => 0 },
) or die $!;                                                                                                                 

# code

sub bot_start {
# inits
my $kernel = $_[KERNEL];
my $heap = $_[HEAP];
my $irc = $heap->{irc};

#system("clear");
print "$0 version $v starting $botnick,$irc...\n";
# terminal
$heap->{stdout} = new POE::Wheel::ReadWrite                                                                                     
    (   Handle     => *STDOUT,                                                                                                      
        Driver     => new POE::Driver::SysRW,                                                                                       
        Filter     => new POE::Filter::Stream,                                                                                      
        ErrorEvent => 'term_error',                                                                                                 
    );                                                                                                                              

$heap->{stdin} = new POE::Wheel::ReadWrite                                                                                      
    (   Handle      => *STDIN,                                                                                                      
        Driver      => new POE::Driver::SysRW,                                                                                      
        Filter      => new POE::Filter::Stream,                                                                                     
        InputEvent  => 'term_input',                                                                                                
        ErrorEvent  => 'term_error',                                                                                                
    );
    
# irc
# $heap->{irc}->yield
my $ircserver = pop (@servers);
print "connecting irc server:$ircserver ($stunnel_host,$stunnel_port)...\n";
my @in = sort @SITES;
my %fishes;
my %fk;
$fk{$masterchannel} = $masterbfkey;
foreach my $ele (@in) {
	# TODO extract chan/key from after login
	my $schan = $cfgsite->param("$ele.chan");
	my $sbfkey = $cfgsite->param("$ele.bfkey");
	if($schan) {
	my $cb = $schan."+".$sbfkey;
	$fishes{$ele} = $cb;
	$fk{$schan} = $sbfkey;		
	}
} 
foreach my $nemo (sort keys %fk) {
	print "$nemo ->".$fk{$nemo}."\n";
}

 $irc->plugin_add( 'BlowFish' =>
              POE::Component::IRC::Plugin::Blowfish->new( %fk ) );
$irc->yield(register => "all" );
$irc->yield(connect =>
    {
    Server   => $stunnel_host,
    Port     => $stunnel_port,
    Nick     => $botnick,
    });
    
# wait until irc is really connected to start things
# see the on_connect handler
# TODO implement 433 nick in use
}

sub arraydiff (\@@) {
# @old minus @new
my $a = shift;
my %found;
$found{$_}++ for @_;
grep !$found{$_}, @$a
}

sub term_error {                                                                                                                    
my ($heap, $operation, $errnum, $errstr) = @_[HEAP, ARG0, ARG1, ARG2];                                                            
print "error: $operation $errnum: $errstr\n";                                                                            
}    

sub term_input {                                                                                                                    
my ($heap, $operation, $errnum, $errstr, $kernel) = @_[HEAP, ARG0, ARG1, ARG2, KERNEL];                                           
chomp($operation);                                                                                                                

if($operation =~ /^wakeup/)
    {
    print "[wakeup!] now building sites connections pool, please wait ...\n";
    $kernel->delay("log_and_idle",5);
    }
elsif($operation =~ /^raw/)
    {
    my @in = split(' ',$operation);
    my @comm = @in[1..($#in-1)];
    my $where = $in[-1];
    unless($in[2])
	{
	print "syntax is : raw <command> <where|ALL>\n";
	return;
	}
    if($where ne "ALL")
	{
	my $raw = getconn_from_site($where);
	unless($raw)
	    {
	    print "sorry, $where isn\'t connected\n";
	    return;
	    }
	site_lock($where);
	$raw->quot("SITE","".join(' ',@comm)."");
	my @mess = $raw->message();
	foreach my $out (@mess)
	    {
	    print "[$where][raw] $out";
	    }
	site_unlock($where);
	}
	else
	{
	# same command everywhere
	}
    }
elsif($operation =~ /^help/)
{
print "quick commands :\n";
print " help\n";
print " fxp <what> <from> <to> <to> <to> <to> <..>\n";
print " pre <what> <where>\n";
print " pre <what> ALL\n";
print " status\n";
print " raw <ftp command> <where>\n";
print " raw <ftp command> ALL\n";
print " quit \n";
return;
}
elsif($operation =~ /^quit/)
{
print "bye bye !\n";
exit;
}
elsif($operation =~ /^fxp/)
    {
    # split : fxp=0, what=1, from=2, to=3..end
    my @in = split(' ',$operation);
    my @to = @in[3..($#in)];
    my $what = $in[1];
    my $from = $in[2];
    my $to = join(',',@to);
    unless($to)
	{
	print "syntax is : fxp <release> <from> <to> <to> <to> <..>\n";
	return;
	}

    my @layout;
    foreach my $target (@to) {push @layout, "$from=>$target";}
    print "[fxp request!] moving $what using ".join(',',@layout)."\n";
    
    my $now = localtime;
    open(LOG,">>$logfile");
    print LOG ">>> $now\n";
    print LOG "[fxp request!] moving $what using ".join(',',@layout)."\n";
    close(LOG);
    
    # fxp is handled in a separate process because it performs blocking Net::FTP operations
    my $task = POE::Wheel::Run->new(
    Program => sub {fxp($what,$from,@to)},
    StdoutEvent => "st_out",
    StderrEvent => "st_err",
    CloseEvent  => "st_cl");
    $_[HEAP]->{task}->{ $task->ID } = $task;    
    }
elsif($operation =~ /^pre/)
    {
    my @in = split(' ',$operation);
    my $what = $in[1];
    my $where = $in[2];
    unless($where)
	{
	print "syntax is : pre <release> where|ALL\n";
	return;
	}
    if($where eq "ALL")
	{
	print "[pre request!] preing $what everywhere\n";
	
	my $now = localtime;
	open(LOG,">>$logfile");
	print LOG ">>> $now\n";
	print LOG "[pre request!] preing $what everywhere\n";
	close(LOG);
	
	foreach my $hq (sort keys %idle)
	    {
	    # get the syntax
	    my @pre = split(' ',$precmd{$hq});
	    foreach my $in (@pre)
		{
		$in =~ s/%s/$what/;
		}
	    print "[$hq][syntax] SITE ".join(',',@pre)."\n";
	    site_lock($hq);
	    $idle{$hq}->quot("SITE","".join(' ',@pre)."");
	    my @answer = $idle{$hq}->message();
	    site_unlock($hq);
	    print "pre sent to $hq!\n";
	    my $now = localtime;
	    open(LOG,">>$logfile");
	    print LOG ">>> $now\n";
	    foreach my $an (@answer)
		{
		print "[$hq][pre] $an ";
		print LOG "[$hq][pre] $an";
		}
	    close(LOG);
	    }
	print "pre sent to all sites!\n";
	}
	else
	{
	print "[pre request!] preing $what on $where\n";
	# get the syntax
	my @pre = split(' ',$precmd{$where});
	foreach my $in (@pre)
	    {
	    $in =~ s/%s/$what/;
	    }
	print "[$where][syntax] SITE ".join(' ',@pre)."\n";
	site_lock($where);
	if(grep{$_ eq $where} keys %idle)
	    {
	    $idle{$where}->quot("SITE","".join(' ',@pre)."");
	    my @answer = $idle{$where}->message();
	    print "pre sent to $where!\n";
	    foreach my $an (@answer)
		{
		print "[$where][pre] $an";
		}
	    }
	else
	    {
	    print "sorry, $where isn\'t connected!\n";
	    site_unlock($where);
	    return;
	    }
	site_unlock($where);
	}
    # fxp($what,$from,$to);
    }
elsif($operation =~ /^status/)
    {
    foreach my $k (sort keys %spread)
	{
	print "$k spreads ".join(',',@{$spread{$k}})."\n";
	}
    return;
    }
else
    {
    print "unknown command : $operation\n";
    return;
    }
}

my $ip;
my $port;

sub log_and_idle {
my ($kernel, $heap) = @_[KERNEL, HEAP];
print "[startup] launching idle module, this may take a while...\n";
$heap->{irc}->yield(privmsg => $supermaster, "[startup] launching idle module, this may take a while...\n");
%idle=();
%idlecmd=();
%logincmd=();
my @in = sort @SITES;
my @not_because_set_to_down;                                                                                                    
my @not_because_idling_is_disabled; 
my $tot;
foreach my $ele (@in)                                                                                                           
{                                                                                                                               
$tot++;                                                                                                                         
my $name = $ele;                                                                                                                
$kernel->yield("site_connect");
# get all bouncers
for(my $b=0; $b<10; $b++)
    {
    next unless($cfgsite->param("$ele.bnc$b"));
    # print "found $ele bnc$b\n";
    my $host = $cfgsite->param("$ele.bnc$b");
    # print "host is $host \n";
    $bncs{"$ele.bnc$b"} = $host;
    }                                                    
my $login = $cfgsite->param("$ele.login");                                                                                      
my $pwd = $cfgsite->param("$ele.pwd");                                                                                          
my $dtoday = $cfgsite->param("$ele.dtoday");                                                                                    
$default_dir{$ele} = $dtoday;
$precmd{$ele} = $cfgsite->param("$ele.pre");                                                                     
$idlecmd{$ele} = $cfgsite->param("$ele.idlecmd") || "STAT"; #raw NOOP ?                                                                     
my @logincmd = split(' ',$cfgsite->param("$ele.logincmd")); my $clen = @logincmd;
# print join(',',@logincmd);
$logincmd{$ele} = \@logincmd if($clen >= 0);                                                                 
my $noidle = $cfgsite->param("$ele.noidle");                                                                                    
my $box_up = $cfgsite->param("$ele.up"); # 0 is down
if($noidle)                                                                                                                     
    {                                                                                                                               
    # print "[skip] $ele idling is disabled\n";                                                                                 
    push @not_because_idling_is_disabled, $ele;                                                                                 
    next;                                                                                                                       
    }                                                                                                                               
unless($box_up)                                                                                                                 
    {                                                                                                                               
    # print "[skip] $ele is set to down\n";                                                                                     
    push @not_because_set_to_down, $ele;                                                                                        
    next;                                                                                                                       
    }                                                                                                                               
unless($dtoday)                                                                                                                 
    {                                                                                                                               
    print "[skip] no predir/todaydir is set for $ele !\n";                                                                            
    next;                                                                                                                       
    }   
unless($precmd{$ele})                                                                                                                 
    {                                                                                                                               
    print "[skip] no pre command is set for $ele !\n";                                                                            
    next;                                                                                                                       
    }   

# debug    
my $fdebug = $cfgsite->param("$ele.debug");
print "[debug] warning, debug mode enabled on $ele !\n" if $fdebug;
$heap->{irc}->yield(privmsg => $supermaster, "warning, debug mode enabled on $ele !\n") if $fdebug;
unless($name)                                                                                                                   
   {                                                                                                                               
   # this is a fix for last line                                                                                                   
   return 0;                                                                                                                       
   }                 

# chains  
my @chains = split(',',$cfgsite->param("$ele.spread")); my $lchains = @chains;
$spread{$ele} = \@chains if($lchains > 0);                                                              

# per-site timeout
my $site_timeout = $cfgsite->param("$ele.timeout");                                                                             
$site_timeout = $timeout unless ($site_timeout);                                                                                
                                                                              
# passive mode on/off    
my $fidle="";
my $passive = 1;
if($cfgsite->param("$ele.passive"))
    {                                        
    print "passive mode off on $ele\n";
    $passive=0;
    }
	
# per-site debug overrides global debug
if($fdebug)                                                                                                                     
    {                                                                                                               
    $fidle = Net::FTP->new($ip, Timeout => $site_timeout, Port => $port, Debug => 1, Passive => $passive,SSL_verify_mode => 0);                                 
    }
    else
    {
    # try to build a connection using 1st bnc found
    my @infos = split('\:',$bncs{"$ele.bnc0"});
    $ip = $infos[0];
    $port = $infos[1];
	$fidle = Net::FTP->new($ip, Timeout => $site_timeout, Port => $port, Debug => $debugftp, Passive => $passive,SSL_verify_mode => 0);                         
    }
                                                                         
# ftp object creation failed
unless(defined $fidle)
    {
    # print "[startup] connection failed on $name (bnc0) ($!)\n";                       
    # $kernel->post( pfxp => privmsg => $supermaster, "connection failed on $name (bnc0)...\n");                                 
    # try the other bouncers
    my $altsuccess;
    foreach my $other (keys %bncs)
        {
	if($other =~ /^$name\.bnc(\d)/)
	    {
	    next if($1 == 0);
	    print "[site:$name] trying $bncs{$other} (bnc$1)\n";
	    $heap->{irc}->yield(privmsg => $supermaster, "[site:$name] trying $bncs{$other} (bnc$1)...\n");
	    my @infos = split('\:',$bncs{"$ele.bnc$1"});
	    $ip = $infos[0];
	    $port = $infos[1];
		$fidle = Net::FTP->new($ip, Timeout => $site_timeout, Port => $port, Debug => $debugftp, Passive => $passive,SSL_verify_mode => 0);                         
		
	    if(defined $fidle)
		{
		print "[site:$name] $ip:$port connected (bnc$1)\n";
		$heap->{irc}->yield(privmsg => $supermaster, "[site:$name] $ip:$port connected (bnc$1)\n");
		$bncconn{$name} = $1;
		$altsuccess++;
		last;
		}	
	    }
	}
	
     unless($altsuccess)
        {
	unless(grep {$_ eq $name} @failures)                                                                                       
	    {                                                                                                                          
	    push @failures,$name;                                                                                                  
	    $all_bnc_down{$name}=1;
	    # print "[startup] connection failed on $name ($!)\n";
	    $heap->{irc}->yield(privmsg => $supermaster, "[$name] couldnt connect any bouncer !\n");                    
	    }                                                                                                                          
	}
    }                                                      
# ftp object creation succeded
if(defined $fidle)                                                                                                              
    {
    # try to login           
    $fidle->starttls();                                                                                                                    
    $fidle->login("$login","$pwd");  
    my $code = $fidle->code();                                                                                                      
    # print "[$name] idle login has code $code\n";                                                                           
    unless($fidle->code() == 230)                                                                                                   
    {                                                                                                                               
     if($code == 530)                                                                                                           
     {                                                                                                                       
     print "[site:$name] login sent 530 reply : ".$fidle->message()."\n";                                                
     }                                                                                                                       
     else                                                                                                                    
     {                                                                                                                       
     print "[site:$name] login sent reply : ".$fidle->message()."\n";                                                    
     }                                                                                                                       
  # print "[startup] Message for $name was : ".$fidle->message()."\n";                                                       
   unless(grep {$_ eq $name} @failures)                                                                                       
    {                                                                                                                          
    push @failures,$name;                                                                                                  
    print "[site:$name] $name sent to failures\n";                                                                     
    }                                                                                                                          
   }              
  
  # login succeded               
  if($fidle->code == 250 || $fidle->code == 230)                                                                                  
  {        
    $fidle->quot("SITE XDUPE 3");                                                                                               

  $fidle->cwd("$dtoday");                                                                                                     
  $idle{$name}=$fidle;           # fill the hash                                                                                             
  $num++;                                                                                                                     
  $failcount{$name}=0;        
  print "[site:$name] login successfull\n";                                                                           
  $heap->{irc}->yield(privmsg => $supermaster, "[site:$name] login successfull\n");
  if($logincmd{$name})
    {
    my @after = @{$logincmd{$name}};
    my $lafter = @after;
    if($lafter == 0)
	{
	$fidle->quot("".$after[0]."");
	}
	elsif($lafter == 1)
	{
	$fidle->quot("".$after[0]."","".$after[1]."");
	}
	elsif($lafter == 2)
	{
	$fidle->quot("".$after[0]."","".$after[1]."","".$after[2]."");
	}
	elsif($lafter == 3)
	{
	$fidle->quot("".$after[0]."","".$after[1]."","".$after[2]."","".$after[3]."");
	}	
	else
	{
	print "[warning] ".join(' ',@after)." doesnt seem to be a valid login cmd\n";
	}
	
    }
  }
}
}

print "[skipped because set to down]: ".join(',',@not_because_set_to_down)."\n";                                               
$heap->{irc}->yield(privmsg => $supermaster, "[skipped because set to down]: ".join(',',@not_because_set_to_down)."\n");
print "[skipped because idling disabled]: ".join(',',@not_because_idling_is_disabled)."\n";                                    
$heap->{irc}->yield(privmsg => $supermaster, "[skipped because idling disabled]: ".join(',',@not_because_idling_is_disabled)."\n");
print "[skipped because problem]: ".join(',',@failures)."\n";                                    
$heap->{irc}->yield(privmsg => $supermaster, "[skipped because problem]: ".join(',',@failures)."\n");
print "[total sites connected]: $num out of possible $#in \n";
$heap->{irc}->yield(privmsg => $supermaster, "[total sites connected]: $num out of possible $#in \n");
foreach my $ch (keys %spread)
    {
    # check for bad chains
    my @chains = @{$spread{$ch}};
    print "[chains] $ch > ".join(',',@chains)."\n";
    # broken source
    unless(grep{$_ eq $ch} keys %idle)
	{
	my $jchains = join(',',@chains);
	print "[chains][warning] $ch is set to spread $jchains but $ch is down!\n";
	$heap->{irc}->yield(privmsg => $supermaster, "[chains][warning] $ch is set to spread $jchains but $ch is down!\n");
	print "[chains] adding $jchains to $dump chains\n";
	$heap->{irc}->yield(privmsg => $supermaster, "[chains] adding $jchains to $dump chains\n");
	# append to dump if exists
	if($spread{$dump})
	{
	my @dtargets = @{$spread{$dump}};
	push @dtargets, @chains;
	$spread{$dump} = \@dtargets;
	}
	else
	{
	$spread{$dump} = $spread{$ch};
	}
	delete $spread{$ch};
	next;
	}
    # recursive checks
    foreach my $chb (keys %spread)
	{
	# print "chb is $chb\n";
	foreach my $within (@chains)
	{
	my @chb = @{$spread{$chb}};
	foreach my $bwithin (@chb)
	{
	if($bwithin eq $within)
	    {
	    if($ch ne $chb)
		{
		print "[chains][warning] $within is already spread from $chb\n";
		$heap->{irc}->yield(privmsg => $supermaster, "[chains][warning] $within is already spread from $chb\n");
		print "[chains] removing $within from $ch>".join(',',@chains)." chain\n";
		$kernel->post( pfxp => privmsg => $supermaster, "[chains] removing $within from $ch>".join(',',@chains)." chain\n");
		my @updated = @chains;
		@updated = grep{$_ ne $within} @chains; my $len = @updated;
		if($len > 0)
		{
		print "[chains] $ch chain is now $ch>".join(',',@updated)."\n";
		$heap->{irc}->yield(privmsg => $supermaster, "[chains] $ch chain is now $ch>".join(',',@updated)."\n");
		$spread{$ch} = \@updated;
		}
		else
		{
		print "[chains] $ch chain is now empty, removing it\n";
		$heap->{irc}->yield(rivmsg => $supermaster, "[chains] $ch chain is now empty, removing it\n");
		delete $spread{$ch};
		}
		}
	    }
	}
	}
	}
    }
print "[chains status] :\n";
$heap->{irc}->yield(privmsg => $supermaster, "[chains status] :\n");
foreach my $k (sort keys %spread)
	{
	print "# $k spreads ".join(',',@{$spread{$k}})."\n";
	$heap->{irc}->yield(privmsg => $supermaster, "# $k spreads ".join(',',@{$spread{$k}})."\n");
	}
$kernel->yield("keep_idle",5); 
}


sub keep_idle {
my $kernel = $_[KERNEL];
my $heap = $_[HEAP];
#print "[debug] i am keep_idle $kernel!\n";
@are_in_use = "";                                                                                                               
foreach my $use (keys %are_used)                                                                                                
    {                                                                                                                               
    # print "in use : $use - \n";                                                                                                   
    push @are_in_use,$use; # only reason of it is because I like grep, hah !                                                        
    }    
foreach my $key (sort keys %idle)                                                                                                    
   {                                                                                                                           
   # print "pushing $key\n";                                                                                                   
   push @connected,$key unless (grep {$_ eq $key} @connected);                                                                 
   # print "conn is ".join(',',@connected)."\n";                                                                               
   if(grep{$_ eq $key} @are_in_use)                                                                                            
   {                                                                                                                           
   print "[busy] $key is in use, I won't idle it\n";                                                                           
   next;                                                                                                                       
   }
   
   if(length($key) > 1)                                                                                                        
   {                                                                                                                           
   #print "ZZZ$key.$idle{$key}\n";                                                                                             
   my $code=0;                                                                                                                 
   if(exists $idle{$key})                                                                                                      
   {                                                                                                                                                                                                                 
   my $faileval=0;                                                                                                             
   my $icomm = $idlecmd{$key};                                                                                       
   eval{$idle{$key}->quot("$icomm")};
   if($@) {                                                                                                                    
           print "[EVAL failed] : $@ \n";                                                                                          
           $faileval=1;                                                                                                                
           }
   unless($faileval){                                                                                                          
   $code=$idle{$key}->code();                                                                                              
   my $l;                           	  
   print "[idle] idle code is $code for $key \n" if($code != 211);
   }
   
   unless($code == 200 or $code == 230 or $code == 250 or $code == 213 or $code == 211 or $code == 226)                        
   {                                                                                                                           
   print BOLD RED "[idle] problem occured on $key, trying to reconnect.. error code was $code\n";                              
   # reconnect code here, remove dead site from hash, recreate connection, then put new connection back into hash              
   delete($idle{$key});                                                                                                        
   my $try = &reconnect_to_site($key,0,$kernel,$heap);  
   if($try)                                                                                                                    
       {                                                                                                                           
       $idle{$key}=$try;                                                                                                           
       }                                                                                                                           
       else{                                                                                                                       
       # push name of failed site in failures again
       unless (grep{$_ eq $key} @failures)                                                                                     
	    {                                                                                                                       
	    push @failures,$key;
	    }                                                                                                                       
       }                                                                                                                       
    }
    
    # read the failures
    foreach my $failed (@failures)                                                                                                  
    {                                                                                                                               
    my $canremovefailed=0;                                                                                                      
    unless($master_warned{$failed})
    {
    print "[retry] $failed idle failed, trying to reconnect now... \n";                                                   
    }
    my $failedretry = &reconnect_to_site($failed,0,$kernel,$heap);                                                                    
    if($failedretry)                                                                                                            
    {                                                                                                                           
    $idle{$failed}=$failedretry;                                                                                                
    $canremovefailed=1;                                                                                                         
    }                                                                                                                           
    else                                                                                                                        
    {                                                                                                                           
    # ...                                                                                                                       
    }                                                                                                                           
    if($canremovefailed)                                                                                                        
    {                                                                                                                           
    @failures = grep {$_ ne $failed} @failures;                                                                                 
    }                                                                                                                           
    }
    # eof failures

    }
    $kernel->delay("keep_idle",20); # loop                                                                                                
    }																		        }                                           
}

sub reconnect_to_site {
my ($site,$kg,$k,$heap) = @_;           
# see if we reached max failures count
if($failcount{$site} > $cfgapp->param("bot.maxfail"))                                                                         
        {                                                                                                                               
	unless($master_warned{$site})                                                                                                   
    	{                                                                                                                           
        print "[reconnect] too many failures (".$failcount{$site}.",".$master_warned{$site}.") for $site, not reconnecting it \n";                                                                   
        delete($idle{$site});                                                                                                           
        # lets notice our master of failure if he doesnt look at shell (only one warning)                                               
	# print "[warning] too many failures (".$failcount{$site}.") for $site, not reconnecting it, look at shell :> \n";
	$master_warned{$site}=1;                                                                                                    
	}                                                                                                                           
	return 0;                                                                                                                       
	}                     
	
my $reco;                                                                                                                       
my $valid;                                                                                                                      
my $ready=0;                                  

if(grep{$_ eq $site} @SITES) # ugly                                                                                          
    {                                   
    
    # on startup all bouncers are checked, dont waste more time..
    if($all_bnc_down{$site})
	{
	unless($master_warned{$site})
	    {
	    print "[reconnect] all $site bouncers failed at startup, $site is probably down, not retrying !\n";
	    $heap->{irc}->yield(privmsg => $supermaster, "[reconnect] all $site bouncers failed at startup, $site is probably down, not retrying !\n");
	    $master_warned{$site}=1;                                                                                                    
	    }
	return 0;                                                                                 
	}
	
    # if one bnc goes down, try the following ones
    my $passive = 1;
    my $login;
    my $pwd;
    my $dtoday;
    my $site_timeout = $cfgsite->param("$site.timeout");                                                                             
    $site_timeout = $timeout unless ($site_timeout);                                                                                
    foreach my $other (keys %bncs)
        {
	if($other =~ /^$site\.bnc(\d)/)
	    {
	    # next if($1 == $bncconn{$site}); # current bnc connection
	    print "[reconnect][$site] now trying $bncs{$other} (bnc$1)\n";
	    $heap->{irc}->yield(privmsg => $supermaster, "[reconnect][$site] now trying $bncs{$other} (bnc$1)\n");
	    $login = $cfgsite->param("$site.login");      
	    if($kg)
	    {
	    $login = "!".$login;
	    print "[reconnect] killghost enabled on $site with $login\n";
	    }                                                                        
	    $pwd = $cfgsite->param("$site.pwd");                                                                                         
	    $dtoday = $cfgsite->param("$site.dtoday");                                                                                               
	    if($cfgsite->param("$site.passive")){$passive = 0;}
	    my @infos = split('\:',$bncs{"$site.bnc$1"});
	    $ip = $infos[0];
	    $port = $infos[1];
		$reco = Net::FTP->new($ip, Timeout => $site_timeout, Port => $port, Debug => $debugftp, Passive => $passive,SSL_verify_mode => 0);                         
	    if(defined $reco)
	    {
	    last;
	    }
	    }
	}

    if(defined $reco)                                                                                                               
    {    
    $reco->starttls();                                                                                                                           
    $reco->login("$login","$pwd"); #or print "login failed on $site ".$reco->message()."\n";                                        
    my $recocode = $reco->code();                                                                                                   
    my $recomess = "";                                                                                                                
    if($kg or $recocode == 530){$recomess = $reco->message();}                                                                      
    unless($recocode == 250 or $recocode == 230)                                                                                    
        {                                                                                                                               
        print "[reconnect] $site sent $recocode code with reply : $recomess\n";                                                              
        }                                                                                                                               
    $failcount{$site}++ if $recocode ==  530;                                                                                       
    return 0 if $recocode == 530; 
    $reco->quot("SITE XDUPE 3");                                                                                                                                                                                                 
    $reco->cwd("$dtoday");                                                                                                          
    print "[reconnect] info for $site reconnect: ".$recocode."\n"; #and ".$recomess."\n"; unless you love ascii hehe        
    $heap->{irc}->yield(privmsg => $supermaster, "[reconnect] info for $site reconnect: ".$recocode."\n");
    $ready = 1 if($recocode == 250 or $recocode == 230);                                                                            
    }
                                                                                                                                   
    $valid = 1 if($ready);                                                                                                          
    }
                                                                                                                                   
    if($valid and defined $reco)                                                                                                    
    {                                                                                                                               
    $master_warned{$site}=0;                                                                                                        
    return $reco;                                                                                                                   
    }                                                                                                                               
    else                                                                                                                            
    {                                                                                                                               
    $failcount{$site}++;                                                                                                            
    print "[status][reconnect] $site failed again, already ".$failcount{$site}." failures \n";                                
    $heap->{irc}->yield(privmsg => $supermaster, "[reconnect] $site failed again, already ".$failcount{$site}." failures \n");
    return 0;                                                                                                                       
    } 
}

sub fxp {
# what, from, to, to, to, to, ..
my ($what,$from,@to) = @_;
foreach my $to (@to)
{
my $source = getconn_from_site($from);
my $dest = getconn_from_site($to);
unless($source && $dest)
    {
    if($source == 0)
	{
	print "[error] sorry, source $from isn\'t connected\n";
	return;
	}
    elsif($dest == 0)
    	{
	print "[error] sorry, target $to isn\'t connected\n";
	next;
	}
    else
	{
	print "[error] source status: $source, dest status: $dest. zero means failed.\n";
	return;
	}
    }
                                                                                                     
    # tell parent to stop idling during fxp process
    # there's a little trick here, if we call site_(un)lock() directly, it will be done in our fxp() child
    # this is not what we want, because the one managing idling is the parent, not the child
    # so we print something to our parent, and let it lock or unlock the site in idle pool
    
    print "[in_use] $from (source of fxp)\n";
    print "[in_use] $to (dest of fxp)\n";
        
    $source->cwd("$what");                                                                                                              
    my $code = $source->code();                                                                                                         
    if($code == 550)                                                                                                                    
    {                                                                                                                               
    print "sorry, $what doesn't exist on $from ! \n";                                                                               
    my $now = localtime;
    open(LOG,">>$logfile");
    print LOG ">>> $now\n";
    print LOG "sorry, $what doesn't exist on $from ! \n";                                                                               
    close(LOG);
    print "[freed] $from (no such directory)\n";
    print "[freed] $to (nothing to move)\n";              
    next;
    # return 0;                                                                                                                           
    }                   
    
    $dest->mkdir("$what");                                                                                                              
    $code = $dest->code();                                                                                                              
    if($code == 550)                                                                                                                    
    {                                                                                                                               
    print "sorry, cant mkdir $what on $to ! \n";                                                                                    
    my $now = localtime;
    open(LOG,">>$logfile");
    print LOG ">>> $now\n";
    print LOG "sorry, cant mkdir $what on $to ! \n";                                                                               
    close(LOG);
    # 1- the dir is already here or 2- there is a real mkdir problem (dupe,chmod,...)                                               
    # $dest->cwd("$what"); # if ok means 1-                                                                                         
    # $source->quit();                                                                                                              
    # $dest->quit();                                                                                                                
    # exit;                                                                                                                         
    }                                                                                                                               
    $dest->cwd("$what");
    #my @files = filter($source->dir()); 
    # subdirs ?
    # ls() = dirname
    # dir() = perm n user grp size day numday hour dirname
    # TODO
    my @dir=();
	my @out=();
	my $failed = 0;
    my $result = $source->quot('STAT -la');
		if($result == 5 || $result eq '') {
			print "STAT -la failed - trying regular dirlist\n";
			$failed=1;
		}
		else {

			@dir=$source->message();
			for my $line (@dir) {
				if($line=~/^(.*)\n$/i) {
					$line=$1;
					# xline pushing -rw-r--r--   1 noir     EPTMP3    8458368 Apr 16 17:08 01-lady_gaga-the_cure-9026142f.mp3
    #print "xline pushing $1\n";               	

				}
				push(@out, $line);
			}
		}
                                                                                                   
    foreach my $line (filter(@out))                                                                                                            
    {
    #print "line is $line\n";               
    if($line =~ /^total/)
	{
	print "not a file : $line\n";
	next;
	}
	    elsif($line =~ /status/i)
	{
	print "not a file : $line\n";
	next;
	}
    elsif($line =~ /^\./)
	{
	print "not a file : $line\n";
	next;
	}
    elsif($line =~ /\[/)
	{
	print "not a file : $line\n";
	next;
	}
    elsif($line =~ /^\.message/)
	{
	print "not a file : $line\n";
	next;
	}
    my @stuff = split(' ',$line);
    if($stuff[0] =~ /^d/)
	{
	my $dir = $stuff[8];
	if($dir =~ /^\./)
	    {
	    next;
	    }
	elsif($dir =~ /\[/)
	    {
	    next;
	    }
    	elsif($dir =~ /\(/)
	    {
	    next;
	    }
	print "[$from][subdir found] : $what/$dir\n";
	my $now = localtime;
	open(LOG,">>$logfile");
	print LOG ">>> $now\n";
	print LOG "[$from][subdir found] : $what/$dir\n";
	close(LOG);
	# mkdir the subdir on destination, fxp files
        $dest->mkdir("$dir");                                                                                                              
	$code = $dest->code();
	if($code == 550)
	    {
	    my $mess = $dest->message();
	    print "[$from>$to] cant mkdir $dir : $mess\n";
	    }
	$dest->cwd("$dir");
	$source->cwd("$dir");
	my @in = $source->ls();
	my @present = $dest->ls();
	# do files already exist on dest ?
	@in = arraydiff @in, @present;
	
	print "IN:".@in.", PRESENT:".@present."\n";

	@in = filter(@in);
	foreach my $ins (@in)
	    {
	    if($ins =~ /^\.message/)
		{
		print "not a file : $ins\n";
		next;
	    }    
	    elsif($ins =~ /^\./)
		{
		print "not a file : $ins\n";
		next;
		}
	    elsif($ins =~ /\[/)
		{
		print "not a file : $ins\n";
		next;
	    }    
	    elsif($ins =~ /missing$/)
		{
		print "not a file : $ins\n";
		next;
		}
	    elsif($ins =~ /^total/)
		{
		print "not a file : $ins\n";
		next;
	    }    
	    else
		{

		print "[$from>$to] A fxping $ins\n";
		if($fxpon) {

		$source->quot('SSCN ON');
		$dest->quot('SSCN OFF');
		$source->pasv_xfer("$ins",$dest);  
		}                                                                                            	
		}	
	    my @mess = $dest->message();
	    my $now = localtime;
	    open(LOG,">>$logfile");
	    print LOG ">>> $now\n";
	    foreach(@mess)
		{
		# try to lower zipscripts garbage to minimum output
		unless(/artist|album|genre|title|year|encoder|preset|binary/i)
		    {
		    print "[$to][$dir status] $_\n";
		    print LOG "[$to][$dir status] $_\n";
		    }
		}
	    close(LOG);
	    }
	$dest->cdup();
	$source->cdup();
	}
    elsif($stuff[0] =~ /^l/)
	{
	print "symlink found : $line\n";
	}
    else
	{ 
	my $file = $stuff[8];
	if($file =~ /^\.message/)
		{
		print "not a file : $file\n";
		next;
		}    
	    elsif($file =~ /\[/)
		{
		print "not a file : $file\n";
		next;
		}
	    elsif($file =~ /missing$/)
		{
		print "not a file : $file\n";
		next;
		}
	    elsif($file =~ /^total/)
		{
		print "not a file : $file\n";
		next;
		}    
	    else 
		{        

	        print "[$from>$to] B fxping $file\n";
		if($fxpon) {

	    $source->quot('SSCN ON');
		$dest->quot('SSCN OFF');
		$source->pasv_xfer("$file",$dest); 
		}                                                                                             
		}
	}
    }                                                                                                                               
    
    # get completion status
    my @mess = $dest->message();
    foreach(@mess)
	{
	unless(/artist|album|genre|title|year|encoder|preset|binary/i)
	    {
	    print "[$to][status] $_\n";
	    }
	}
    
    # get back in predirs
    $source->cwd("".$default_dir{$from}."");
    $dest->cwd("".$default_dir{$to}."");
    
    print "[freed] $from (fxp finished)\n";                
    print "[freed] $to (fxp finished)\n";                                                                                                  
    
    # is spread required from $to ?
    if(exists $spread{$to})
	{
	my @chains = @{$spread{$to}};
	my $jchains = join(',',@chains);
	print "[chain] now fxp'ing $what from $to to $jchains\n";
	print "cchain $what $to $jchains\n";
	# fxp($what,$to,$here);
	}
}    
}

sub site_lock {
my $site = shift;                                                                                                                   
print "[locking $site]\n" if($show_locks);                                                                                                   
delete($are_used{$site});                                                                                                           
$are_used{$site}=1;   
}

sub site_unlock {
my $site = shift;                                                                                                                   
print "[unlocking $site]\n" if($show_locks);                                                                                                                                                                                                           
delete($are_used{$site});                                                                                                           
}


sub getconn_from_site {                                                                                                             
# returns the ftp connection object, if any.                                                                                    
my $site = shift;                                                                                                               
if(exists($idle{$site}))                                                                                                        
    {                                                                                                                               
    return $idle{$site};                                                                                                            
    }                                                                                                                               
    else                                                                                                                            
    {                                                                                                                               
    return 0;                                                                                                                       
    }                                                                                                                               
}                                                                                                                                   

sub st_out {
# handles Wheels outputs
my $result = $_[ARG0];
my ($kernel, $heap) = @_[KERNEL, HEAP];
if($result =~ /^\[in_use/)
    {
    print "got use signal in:$result\n";
    my $name="";
    $name = $1 if $result =~ / (\w+|\S+)/;
    # push @are_in_use,"$name";
    # $are_used{$name}="yes";#unless (exists $are_used{$name}); # unless already exists
    print "[stout] $name wants lock\n";
    &site_lock($name);
    }
elsif($result =~ /^\[freed/)
    {
    my $name;
    print "st_out says:$result\n";
    $name = $1 if $result =~ / (\w+|\S+)/;
    print "[stout] $name wants unlock\n";
    &site_unlock($name);
    }
elsif($result =~ /^cchain/)
    {
    my @args = split(' ',$result);
    my $what = $args[1];
    my $from = $args[2];
    my $to = $args[3];
    my @to = split(',',$to);
    my $task = POE::Wheel::Run->new(
    Program => sub {fxp($what,$from,@to)},
    StdoutEvent => "st_out",
    StderrEvent => "st_err",
    CloseEvent  => "st_cl");
    $_[HEAP]->{task}->{ $task->ID } = $task;    
    }
elsif($result =~ /^\[end/)
    {
    print ">eof!\n";
    return;
    }
else
    {
    print ">$result\n";
    $heap->{irc}->yield(privmsg => $supermaster, "$result\n" );
    return;
    }
}


sub st_err {
}

sub st_cl {
}

sub check_skiplist {
# filter() defaults to nfo/mp3/m3u/jpg/sfv
}

sub filter {
my @a = @_;
my @b;
my @trail;
foreach my $in (@a)
    {
    if($in =~ /nfo$/)
    {
    my @nfo = split('\.',$in);
    if(length($nfo[0]) > 8)
    {
    push @b, $in;
    }
    }
    elsif($in =~ /mp3$/)
    {
    push @b, $in;
    }
    elsif($in =~ /m3u$/)
    {
    push @trail, $in;
    }
    elsif($in =~ /jpg$/)
    {
    push @trail, $in;
    }
    elsif($in =~ /sfv$/)
    {
    push @b, $in;
    }
}
my $len = @b;
my $i;
for($i=0; $i<$len; $i++)
    {
    #print "filter: $b[$i]\n";
    if($b[$i] =~ /sfv$/)
    {
    #	print BOLD RED "sfv first\n";
    my $first = $b[0];
    $b[0] = $b[$i];
    $b[$i] = $first;
    }
    elsif($b[$i] =~ /nfo$/)
    {
    #	print BOLD RED "nfo sec\n";

    my $sec = $b[1];
    $b[1] = $b[$i];
    $b[$i] = $sec;
    }
    }
    push(@b,@trail);
return @b;
}

sub on_connect {
my ( $kernel, $heap ) = @_[ KERNEL, HEAP ];
# greet
print "connected to irc !\n";
# join the channel
$heap->{irc}->yield(join => $masterchannel, $masterchankey );
# $heap->{irc}->yield(privmsg => $masterchannel => 'hello');
# run autoping
$heap->{seen_traffic} = 1;
$kernel->delay( autoping => 300 );
# sites stuff    
# $autoconnect=0;        
unless($autoconnect)
    {
    print "[startup] auto-connect is disabled on sites, please send \"wakeup\" to build sites pool\n";
    }
    else
    {
    print "[startup] now autoconnecting all your sites...\n";
    $heap->{irc}->yield(privmsg => $supermaster, "autoconnecting all hq's please wait ... \n" );
    $kernel->delay("log_and_idle",5);
    }
}

sub on_public {
# public
my ( $kernel, $who, $where, $msg ) = @_[ KERNEL, ARG0, ARG1, ARG2 ];
my ($nick, $ident) = ( split /!/, $who );
print "$nick said $msg\n";

}

sub on_msg {
# pm
my $heap = $_[HEAP];
my ( $kernel, $who, $where, $msg ) = @_[ KERNEL, ARG0, ARG1, ARG2 ];
my ($nick, $ident) = ( split /!/, $who );
unless(check_user($nick))
    {
    $heap->{irc}->yield(privmsg => $nick, "unauthorized privmsg. you have been logged" );
    return;
    }
# actions
if($msg eq "help")
    {
    my @help = ("quick commands :\n", " help\n", " fxp <what> <from> <to> <to> <to> <to> <..>\n", " pre <what> <where>\n", " pre <what> ALL\n", " status\n",  " raw <ftp command> <where>\n",  " raw <ftp command> ALL\n",  " quit \n");
    foreach my $h (@help)
    {
    $heap->{irc}->yield(privmsg => $nick, $h );
    }
    }
elsif($msg =~ /^fxp/)
    {
    # split : fxp=0, what=1, from=2, to=3..end
    my @in = split(' ',$msg);
    my @to = @in[3..($#in)];
    my $what = $in[1];
    my $from = $in[2];
    my $to = join(',',@to);
    unless($to)
	{
	print "syntax is : fxp <release> <from> <to> <to> <to> <..>\n";
	$heap->{irc}->yield(privmsg => $nick, "syntax is : fxp <release> <from> <to> <to> <to> <..>\n" );
	return;
	}

    my @layout;
    foreach my $target (@to) {push @layout, "$from=>$target";}
    print "[fxp request!] moving $what using ".join(',',@layout)."\n";
    $heap->{irc}->yield(privmsg => $nick, "[fxp request!] moving $what using ".join(',',@layout)."\n" );
    my $now = localtime;
    open(LOG,">>$logfile");
    print LOG ">>> $now\n";
    print LOG "[fxp request!] moving $what using ".join(',',@layout)."\n";
    close(LOG);
    
    # fxp is handled in a separate process because it performs blocking Net::FTP operations
    my $task = POE::Wheel::Run->new(
    Program => sub {fxp($what,$from,@to)},
    StdoutEvent => "st_out",
    StderrEvent => "st_err",
    CloseEvent  => "st_cl");
    $_[HEAP]->{task}->{ $task->ID } = $task;
    }
elsif($msg eq "status")
    {
    my @stat;
    foreach my $k (sort keys %spread)
	{
	push @stat, "$k spreads ".join(',',@{$spread{$k}})."\n";
	}
    $heap->{irc}->yield(privmsg => $nick, "[status] chains :\n" );
    foreach my $s (@stat)
	{
	$_[KERNEL]->post( pfxp => privmsg => $nick, $s );
	}
    my @stat_idle;
    foreach my $id (sort keys %idle)
	{
	push @stat_idle, "$id,";
	}
    chop @stat_idle; my $silen = $#stat_idle; $silen++;
    
    $heap->{irc}->yield(privmsg => $nick, "[status] idling on $silen sites : ".join(',',@stat_idle)."\n" );
    $heap->{irc}->yield(privmsg => $nick, "[status] end of status\n" );
    }        
elsif($msg =~ /^pre/)
    {
    my @in = split(' ',$msg);
    my $what = $in[1];
    my $where = $in[2];
    unless($where)
	{
	print "syntax is : pre <release> where|ALL\n";
	$heap->{irc}->yield(privmsg => $nick, "syntax is : pre <release> where|ALL\n" );
	return;
	}
    if($where eq "ALL")
	{
	print "[pre request!] preing $what everywhere\n";
	$heap->{irc}->yield(privmsg => $nick, "[pre request!] preing $what everywhere\n" );
	my $now = localtime;
	open(LOG,">>$logfile");
	print LOG ">>> $now\n";
	print LOG "[pre request!] preing $what everywhere\n";
	close(LOG);
	
	foreach my $hq (sort keys %idle)
	    {
	    # get the syntax
	    my @pre = split(' ',$precmd{$hq});
	    foreach my $in (@pre)
		{
		$in =~ s/%s/$what/;
		}
	    print "[$hq][syntax] SITE ".join(',',@pre)."\n";
	    site_lock($hq);
	    $idle{$hq}->quot("SITE","".join(' ',@pre)."");
	    my @answer = $idle{$hq}->message();
	    site_unlock($hq);
	    print "pre sent to $hq!\n";
	    $heap->{irc}->yield(privmsg => $nick, "pre sent to $hq!\n" );
	    my $now = localtime;
	    open(LOG,">>$logfile");
	    print LOG ">>> $now\n";
	    foreach my $an (@answer)
		{
		print "[$hq][pre] $an ";
		print LOG "[$hq][pre] $an";
		}
	    close(LOG);
	    }
	print "pre sent to all sites!\n";
	$heap->{irc}->yield(privmsg => $nick, "pre sent to all sites!\n" );
	}
	else
	{
	print "[pre request!] preing $what on $where\n";
	$heap->{irc}->yield(privmsg => $nick, "[pre request!] preing $what on $where\n" );
	# get the syntax
	my @pre = split(' ',$precmd{$where});
	foreach my $in (@pre)
	    {
	    $in =~ s/%s/$what/;
	    }
	print "[$where][syntax] SITE ".join(' ',@pre)."\n";
	site_lock($where);
	if(grep{$_ eq $where} keys %idle)
	    {
	    $idle{$where}->quot("SITE","".join(' ',@pre)."");
	    my @answer = $idle{$where}->message();
	    print "pre sent to $where!\n";
	    $heap->{irc}->yield(privmsg => $nick, "pre sent to $where!\n" );
	    foreach my $an (@answer)
		{
		print "[$where][pre] $an";
		}
	    }
	else
	    {
	    print "sorry, $where isn\'t connected!\n";
	    $heap->{irc}->yield(privmsg => $nick, "sorry, $where isn\'t connected!\n" );
	    site_unlock($where);
	    return;
	    }
	site_unlock($where);
	}
    # fxp($what,$from,$to);
    }
elsif($msg =~ /^raw/)
    {
    }    
elsif($msg eq "quit")
    {
    $heap->{irc}->yield(privmsg => $nick, "bye bye !\n" );
    exit;
    }    
else
    {
    $heap->{irc}->yield(privmsg => $nick, "unknown command : $msg \n" );
    }
}

sub site_connect {
my $site = shift;
}

sub check_user {
my $nick = shift;
my $match;
foreach my $user (@masters)
    {
    if($user eq $nick){return 1;}
    }
return 0;
}
			
sub on_disconnect {
# disable ping, wait a little time (?) then reconnect
my ($kernel, $heap, $from) = @_[ KERNEL, HEAP, ARG0];
$kernel->delay( autoping => undef );
my $fresh;
# TODO oidentd servers or pure ssl/znc
foreach my $server (@servers) {next if($server eq $from); $fresh = $server; last; }
print "disconnected from $from, trying $fresh ...\n";
$heap->{irc}->yield(connect =>
    {
    Nick => $botnick,
    Username => 'john',
    Ircname  => 'doe',
    Server   => $fresh,
    Port     => '6667',
    Debug    => $ircdebug,
    Flood    => $flood,
    });
}
			
sub on_nick_taken {
	my ($self) = shift;
	my $session = $poe_kernel->get_active_session();
    my $hheap = $session->get_heap();
	print "nick $botnick taken, switching to nick: $botaltnick\n";
	$hheap->{irc}->yield(nick => "$botaltnick");
}

sub on_invite {
	my ($kernel, $heap, $who, $chan) = @_[ KERNEL, HEAP, ARG0, ARG1];
	my $nick = ( split /!/, $who )[0];
	print "invited by $nick to: $chan\n";
	$heap->{irc}->yield(join => "$chan");
}

sub on_ircerror {
# auto triggers on_disconnect, here only for details
my ( $kernel, $heap, $txt ) = @_[ KERNEL, HEAP, ARG0 ];
print "error from IRC : $txt\n";
}


sub on_ircsocketerr {
# triggered if on_disconnect fails
my ( $kernel, $heap, $txt ) = @_[ KERNEL, HEAP, ARG0 ];
print "socket error from IRC : $txt\n";
}

sub irc_ping {
# staying alive ah ah ah ah
my ( $kernel, $heap ) = @_[ KERNEL, HEAP ];
$heap->{irc}->yield(userhost => "$botnick" ) unless $heap->{seen_traffic};
$heap->{seen_traffic} = 0;
$kernel->delay( autoping => 300 );
}

sub on_ircinvite {
# autojoin on friendly invites
}
					    										
$poe_kernel->run();
exit;












